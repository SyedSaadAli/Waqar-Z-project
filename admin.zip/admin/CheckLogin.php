<?php
if(isset($_SESSION['Admin_Username']))
{
	
} else{
	header('location:../login.php');
}
?>