<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


	<!-- Datatables Example -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="n-0 font-weight-bold text-primary">Add Video Links</h6>

		</div>
		<div class="card-body">


			<form action="code.php" method="POST">


				<div class="form-group">
					<label>Video Links</label>
					<input type="text" name="add_video_links"  value="" class="form-control" placeholder="Enter Video Links">
					<br></div>		
					<div class="form-group">
						<label>Status</label>
						<select name="category" class="form-control">
							<option value="Fashion"> Fashion </option>
							<option value="Food"> Food </option>
							<option value="Product"> Product </option>
							<option value="Wedding"> Wedding </option>
						</select>
					</div>
<br></br>
					<center>

						<a href="index.php" class="btn btn-danger"> CANCEL </a>
						<button type="submit" name="add_v_btn" class="btn btn-primary"> Add </button>
					</center>
				</form>

			<?php 
			include('includes/scripts.php'); 
			include('includes/footer.php'); 
			?>