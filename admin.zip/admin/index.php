<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">

        <div class="card-header py-3">
            <form action="Add.php" method="post">
                <h6 class="n-0 font-weight-bold text-primary">

                	<button style="background-color:000000"; type="button" name="#" class="btn btn-primary" data-toggle="modal" disabled>
                       ADD
                   </button>
<center>
                    <button style="margin:5px;" type="submit" name="fashion" class="btn btn-primary" data-toggle="modal" >
                       FASHION
                   </button>
                   <button style="margin:5px;" type="submit" name="product" class="btn btn-primary" data-toggle="modal" >
                       PRODUCT
                   </button>
                   <button style="margin:5px;" type="submit" name="wedding" class="btn btn-primary" data-toggle="modal" >
                       WEDDING 
                   </button>
                   <button style="margin:5px;" type="submit" name="food" class="btn btn-primary" data-toggle="modal" >
                       FOOD
                   </button>
</center>
               </form>

           </h6> </div>
       </div>
   </div>



   <div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="n-0 font-weight-bold text-primary"> Fashion


            </h6> </div>
            <div class="card-body">

                <?php  
                if(isset($_SESSION['success']) && $_SESSION['success'] != '')
                {
	echo '<h2 class="bg-primary"> '.$_SESSION['success'].' </h2>';# text-white
	unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>

  <div class="table-responsive">

    <?php
    $query = "SELECT * FROM fashion";
    $query_run = mysqli_query($connection, $query);
    ?>
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th> ID </th>
                <th>Image </th>
                <th>Description </th>
                <th>DELETE</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if(mysqli_num_rows($query_run) > 0)        
            {
                while($row = mysqli_fetch_assoc($query_run))
                {
                    ?>
                    <tr>
                        <td><?php  echo $row['Fashion_ID']; ?></td>
                        <td><img style="height: 80px ; width: 100px ;" src=<?php echo $row['Image_Name'];?>></td>
                        <td><?php  echo $row['Image_Description']; ?></td>

                        <td>
                            <form action="code.php" method="post">
                                <input type="hidden" name="f_delete_id" value="<?php echo $row['Fashion_ID']; ?>">
                                <button type="submit" name="f_delete_btn" class="btn btn-danger"> DELETE</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                } 
            }
            else {
                echo "No Record Found";
            }
            ?>
        </tbody>
    </table>

</div>
</div>
</div>
</div>
<!-- /.container-fluid -->




<div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="n-0 font-weight-bold text-primary"> Product


            </h6> </div>
            <div class="card-body">

                <?php  
                if(isset($_SESSION['p_success']) && $_SESSION['p_success'] != '')
                {
    echo '<h2 class="bg-primary"> '.$_SESSION['p_success'].' </h2>';# text-white
    unset($_SESSION['p_success']);
}
if(isset($_SESSION['p_status']) && $_SESSION['p_status'] != '' )
{
      echo '<h2 class="big-danger"> '.$_SESSION['p_status'].' </h2>';# text-white
      unset($_SESSION['p_status']);
  }
  ?>

  <div class="table-responsive">

    <?php
    $query = "SELECT * FROM product";
    $query_run = mysqli_query($connection, $query);
    ?>
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th> ID </th>
                <th>Image </th>
                <th>Description </th>
                <th>DELETE</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if(mysqli_num_rows($query_run) > 0)        
            {
                while($row = mysqli_fetch_assoc($query_run))
                {
                    ?>
                    <tr>
                        <td><?php  echo $row['Product_ID']; ?></td>
                        <td><img style="height: 80px ; width: 100px ;" src=<?php echo $row['Image_Name'];?>></td>
                        <td><?php  echo $row['Image_Description']; ?></td>
                     
                        <td>
                            <form action="code.php" method="post">
                                <input type="hidden" name="p_delete_id" value="<?php echo $row['Product_ID']; ?>">
                                <button type="submit" name="p_delete_btn" class="btn btn-danger"> DELETE</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                } 
            }
            else {
                echo "No Record Found";
            }
            ?>
        </tbody>
    </table>

</div>
</div>
</div>
</div>
<!-- /.container-fluid -->





<div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="n-0 font-weight-bold text-primary"> Wedding


            </h6> </div>
            <div class="card-body">

                <?php  
                if(isset($_SESSION['w_success']) && $_SESSION['w_success'] != '')
                {
    echo '<h2 class="bg-primary"> '.$_SESSION['w_success'].' </h2>';# text-white
    unset($_SESSION['w_success']);
}
if(isset($_SESSION['w_status']) && $_SESSION['w_status'] != '' )
{
      echo '<h2 class="big-danger"> '.$_SESSION['w_status'].' </h2>';# text-white
      unset($_SESSION['w_status']);
  }
  ?>

  <div class="table-responsive">

    <?php
    $query = "SELECT * FROM wedding";
    $query_run = mysqli_query($connection, $query);
    ?>
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th> ID </th>
                <th>Image </th>
                <th>Description </th>
                <th>DELETE</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if(mysqli_num_rows($query_run) > 0)        
            {
                while($row = mysqli_fetch_assoc($query_run))
                {
                    ?>
                    <tr>
                        <td><?php  echo $row['Wedding_ID']; ?></td>
                         <td><img style="height: 80px ; width: 100px ;" src=<?php echo $row['Image_Name'];?>></td>
                        <td><?php  echo $row['Image_Description']; ?></td>

                        <td>
                            <form action="code.php" method="post">
                                <input type="hidden" name="w_delete_id" value="<?php echo $row['Wedding_ID']; ?>">
                                <button type="submit" name="w_delete_btn" class="btn btn-danger"> DELETE</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                } 
            }
            else {
                echo "No Record Found";
            }
            ?>
        </tbody>
    </table>

</div>
</div>
</div>
</div>
<!-- /.container-fluid -->




<div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="n-0 font-weight-bold text-primary"> Food


            </h6> </div>
            <div class="card-body">

                <?php  
                if(isset($_SESSION['f_success']) && $_SESSION['f_success'] != '')
                {
    echo '<h2 class="bg-primary"> '.$_SESSION['f_success'].' </h2>';# text-white
    unset($_SESSION['f_success']);
}
if(isset($_SESSION['f_status']) && $_SESSION['f_status'] != '' )
{
      echo '<h2 class="big-danger"> '.$_SESSION['f_status'].' </h2>';# text-white
      unset($_SESSION['f_status']);
  }
  ?>

  <div class="table-responsive">

    <?php
    $query = "SELECT * FROM food";
    $query_run = mysqli_query($connection, $query);
    ?>
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th> ID </th>
                <th>Image </th>
                <th>Description </th>
                <th>DELETE</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if(mysqli_num_rows($query_run) > 0)        
            {
                while($row = mysqli_fetch_assoc($query_run))
                {
                    ?>
                    <tr>
                        <td><?php  echo $row['Food_ID']; ?></td>
                         <td><img style="height: 80px ; width: 100px ;" src=<?php echo $row['Image_Name'];?>></td>
                        <td><?php  echo $row['Image_Description']; ?></td>

                        <td>
                            <form action="code.php" method="post">
                                <input type="hidden" name="f_delete_id" value="<?php echo $row['Food_ID']; ?>">
                                <button type="submit" name="f_delete_btn" class="btn btn-danger"> DELETE</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                } 
            }
            else {
                echo "No Record Found";
            }
            ?>
        </tbody>
    </table>

</div>
</div>
</div>
</div>
<!-- /.container-fluid -->


<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>