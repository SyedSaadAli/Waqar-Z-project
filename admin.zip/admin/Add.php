<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>




<?php 

if(isset($_POST['fashion'])){

	?>
	<!-- Datatables Example -->
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="n-0 font-weight-bold text-primary">Add Fashion Profile</h6>

		</div>
		<div class="card-body">


			<form action="code.php" method="POST" enctype="multipart/form-data">




				<div class="form-group">
					<label> Image </label>
					<input type="file" name="add_image"  class="form-control" placeholder="Upload Image" >

				</div>
				<div class="form-group">
					<label>Description</label>
					<input type="text" name="add_image_description"  value="" class="form-control" placeholder="Enter Image Description">
					

		<br></div>		
<center>

				<a href="index.php" class="btn btn-danger"> CANCEL </a>
				<button type="submit" name="add_btn" class="btn btn-primary"> Add </button>
</center>
			</form>

			<?php 

		}

		?>

		<?php 

		if(isset($_POST['product'])){

			?>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
					<h6 class="n-0 font-weight-bold text-primary">Add Product Profile</h6>

				</div>
				<div class="card-body">

					<form action="code.php" method="POST" enctype="multipart/form-data">



				<div class="form-group">
					<label> Image </label>
					<input type="file" name="add_image"  class="form-control" placeholder="Upload Image" >

				</div>
				<div class="form-group">
					<label>Description</label>
					<input type="text" name="add_image_description"  value="" class="form-control" placeholder="Enter Image Description">
					</div>
					

				
<center>
				<a href="index.php" class="btn btn-danger"> CANCEL </a>
				<button type="submit" name="add_btn2" class="btn btn-primary"> Add </button>
</center>

					</form>

					<?php 

				}

				?>



				<?php 

				if(isset($_POST['wedding'])){

					?>
					<div class="card shadow mb-4">
						<div class="card-header py-3">
							<h6 class="n-0 font-weight-bold text-primary">Add Wedding Profile</h6>

						</div>
						<div class="card-body">


							<form action="code.php" method="POST" enctype="multipart/form-data">



				<div class="form-group">
					<label> Image </label>
					<input type="file" name="add_image"  class="form-control" placeholder="Upload Image" >

				</div>
				<div class="form-group">
					<label>Description</label>
					<input type="text" name="add_image_description"  value="" class="form-control" placeholder="Enter Image Description">
					</div>
					

				

<center>
				<a href="index.php" class="btn btn-danger"> CANCEL </a>
				<button type="submit" name="add_btn3" class="btn btn-primary"> Add </button>
</center>
							</form>

							<?php 

						}

						?>



				<?php 

				if(isset($_POST['food'])){

					?>
					<div class="card shadow mb-4">
						<div class="card-header py-3">
							<h6 class="n-0 font-weight-bold text-primary">Add Food Profile</h6>

						</div>
						<div class="card-body">


							<form action="code.php" method="POST" enctype="multipart/form-data">



				<div class="form-group">
					<label> Image </label>
					<input type="file" name="add_image"  class="form-control" placeholder="Upload Image" >

				</div>
				<div class="form-group">
					<label>Description</label>
					<input type="text" name="add_image_description"  value="" class="form-control" placeholder="Enter Image Description">
					</div>
					

				
<center>

				<a href="index.php" class="btn btn-danger"> CANCEL </a>
				<button type="submit" name="add_btn4" class="btn btn-primary"> Add </button>
</center>
							</form>

							<?php 

						}

						?>

					</div>
				</div>
			</div>

			<!-- /.container-fluid -->




			<?php 
			include('includes/scripts.php'); 
			include('includes/footer.php'); 
		?>