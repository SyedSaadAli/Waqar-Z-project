<?php 
include('security.php');


if(isset($_POST['f_delete_btn']))
{
    $id = $_POST['f_delete_id'];

    $query = "DELETE FROM fashion WHERE Fashion_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Fashion Profile is Deleted";
        $_SESSION['status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Fashion Profile is NOT DELETED";       
        $_SESSION['status_code'] = "error";
        header('Location: index.php'); 
    }    
}




// ----------------------------------------------------------------------------------------------------------


if(isset($_POST['p_delete_btn']))
{
    $id = $_POST['p_delete_id'];

    $query = "DELETE FROM product WHERE Product_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['p_status'] = "Your Product Profile is Deleted";
        $_SESSION['p_status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['p_status'] = "Your Product Profile is NOT DELETED";       
        $_SESSION['p_status_code'] = "error";
        header('Location: index.php'); 
    }    
}




// ----------------------------------------------------------------------------------------------------------


if(isset($_POST['w_delete_btn']))
{
    $id = $_POST['w_delete_id'];

    $query = "DELETE FROM wedding WHERE Wedding_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['w_status'] = "Your Wedding Profile is Deleted";
        $_SESSION['w_status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['w_status'] = "Your Wedding Profile is NOT DELETED";       
        $_SESSION['w_status_code'] = "error";
        header('Location: index.php'); 
    }    
}



// ----------------------------------------------------------------------------------------------------------


if(isset($_POST['f_delete_btn']))
{
    $id = $_POST['f_delete_id'];

    $query = "DELETE FROM food WHERE Food_ID='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['f_status'] = "Your Food Profile is Deleted";
        $_SESSION['f_status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['f_status'] = "Your Food Profile is NOT DELETED";       
        $_SESSION['f_status_code'] = "error";
        header('Location: index.php'); 
    }    
}

// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['add_btn']))
{

    $add_image_description = $_POST['add_image_description'];
    


    $target_dir = "Images/Fashion/";
    $target_file = $target_dir . basename($_FILES["add_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image

    $check = getimagesize($_FILES["add_image"]["tmp_name"]);
    if($check !== false) {
   # echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
        $ImageName = $_FILES['add_image']['name'];
        $fileElementName = 'add_image';
        $path = 'Images/Fashion/'; 
        $location = $path . $_FILES['add_image']['name']; echo $location;

        move_uploaded_file($_FILES['add_image']['tmp_name'], $location); 
    } else {
   # echo "File is not an image.";
        $uploadOk = 0;
    }


    $query = "INSERT INTO fashion (Image_Name,Image_Description,Fashion) VALUES 
    ('$location','$add_image_description','$V_location')";
    $query_run = mysqli_query($connection, $query);


    if($query_run)
    {
        $_SESSION['status'] = "Your Fashion Profile is Added";
        $_SESSION['status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Fashion Profile is NOT Added";
        $_SESSION['status_code'] = "error";
        header('Location: index.php');  
    }
}

// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['add_btn2']))
{

 
    $add_image_description = $_POST['add_image_description'];
    


    $target_dir = "Images/Product/";
    $target_file = $target_dir . basename($_FILES["add_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image

    $check = getimagesize($_FILES["add_image"]["tmp_name"]);
    if($check !== false) {
   # echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
        $ImageName = $_FILES['add_image']['name'];
        $fileElementName = 'add_image';
        $path = 'Images/Product/'; 
        $location = $path . $_FILES['add_image']['name']; echo $location;

        move_uploaded_file($_FILES['add_image']['tmp_name'], $location); 
    } else {
   # echo "File is not an image.";
        $uploadOk = 0;
    }


    $query = "INSERT INTO product (Image_Name,Image_Description) VALUES 
    ('$location','$add_image_description')";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['p_status'] = "Your Product Profile is Added";
        $_SESSION['p_status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['p_status'] = "Your Product Profile is NOT Added";
        $_SESSION['p_status_code'] = "error";
        header('Location: index.php');  
    }
}



// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['add_btn3']))
{

    $add_image_description = $_POST['add_image_description'];
    


    $target_dir = "Images/Wedding/";
    $target_file = $target_dir . basename($_FILES["add_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image

    $check = getimagesize($_FILES["add_image"]["tmp_name"]);
    if($check !== false) {
   # echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
        $ImageName = $_FILES['add_image']['name'];
        $fileElementName = 'add_image';
        $path = 'Images/Wedding/'; 
        $location = $path . $_FILES['add_image']['name']; echo $location;

        move_uploaded_file($_FILES['add_image']['tmp_name'], $location); 
    } else {
   # echo "File is not an image.";
        $uploadOk = 0;
    }


    $query = "INSERT INTO wedding (Image_Name,Image_Description) VALUES 
    ('$location','$add_image_description')";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['w_status'] = "Your Wedding Profile is Added";
        $_SESSION['w_status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['w_status'] = "Your Wedding Profile is NOT Added";
        $_SESSION['w_status_code'] = "error";
        header('Location: index.php');  
    }
}

 


// ----------------------------------------------------------------------------------------------------------




if(isset($_POST['add_btn4']))
{

    $add_image_description = $_POST['add_image_description'];
    


    $target_dir = "Images/Food/";
    $target_file = $target_dir . basename($_FILES["add_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image

    $check = getimagesize($_FILES["add_image"]["tmp_name"]);
    if($check !== false) {
   # echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
        $ImageName = $_FILES['add_image']['name'];
        $fileElementName = 'add_image';
        $path = 'Images/Food/'; 
        $location = $path . $_FILES['add_image']['name']; echo $location;

        move_uploaded_file($_FILES['add_image']['tmp_name'], $location); 
    } else {
   # echo "File is not an image.";
        $uploadOk = 0;
    }


    $query = "INSERT INTO food (Image_Name,Image_Description) VALUES 
    ('$location','$add_image_description')";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['f_status'] = "Your Food Profile is Added";
        $_SESSION['f_status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['f_status'] = "Your Food Profile is NOT Added";
        $_SESSION['f_status_code'] = "error";
        header('Location: index.php');  
    }
}



// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['add_v_btn']))
{

    $add_video_links = $_POST['add_video_links'];
    $category = $_POST['category'];



    $query = "INSERT INTO video (V_Link,Category) VALUES 
    ('$add_video_links','$category')";
    $query_run = mysqli_query($connection, $query);
    header('Location: index.php'); 
}

?>